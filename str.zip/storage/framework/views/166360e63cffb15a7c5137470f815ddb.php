<?php $__env->startSection('title'); ?>
<!-- Title here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-css'); ?>
<!-- Additional CSS here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-styles'); ?>
<!-- Additional styles here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main content here -->
<div class="main_slider" style="background-image: url(<?php echo e(asset('global/landingpage/images/slider_1.jpg')); ?>)">
    <!-- Slider content here -->
    <?php if(session('success')): ?>
    <div class="row">
        <div class="col text-center">
            <div class="alert alert-success" id="welcomeMessage">
                <?php echo e(session('success')); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(session('suuccess')): ?>
    <div class="row">
        <div class="col text-left">
            <div class="alert alert-success" id="welcomeMessage">
                <?php echo e(session('success')); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
    <div class="row" id="welcomeMessage">
        <div class="col text-left">
            <div id="notification" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: #FFE4C4; color: #333; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);">
                <span onclick="closeNotification()" style="position: absolute; top: 10px; right: 10px; cursor: pointer; font-size: 60px;">&times;</span>
                <h2 style="font-family: 'Arial', sans-serif; margin: 0;">Selamat Datang, <?php echo e(Auth::user()->name); ?>!</h2>
                <p style="font-size: 16px; margin-top: 10px;">Catatan: Semua fitur Sorting di sini telah diaktifkan, mulai dari penyesuaian berdasarkan kategori, harga, hingga pengurutan berdasarkan abjad.</p>
                <!-- Tambahkan elemen desain lainnya sesuai keinginan -->
            </div>

            <script>
                // Fungsi untuk menutup pemberitahuan
                function closeNotification() {
                    document.getElementById('notification').style.display = 'none';
                }
                // Tampilkan pemberitahuan setelah halaman dimuat
                document.addEventListener('DOMContentLoaded', function() {
                    document.getElementById('notification').style.display = 'block';
                });
            </script>
        </div>
    </div>


    <?php endif; ?>
</div>

<div class="banner">
    <!-- Banner content here -->
</div>

<div class="new_arrivals">
    <!-- New Arrivals content here -->
    <div class="container">
        <div class="row">
            <div class="col text-center">
                <div class="section_title new_arrivals_title">
                    <h2>New Arrivals</h2>
                </div>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col text-center">
                <div class="new_arrivals_sorting">
                    <ul class="arrivals_grid_sorting clearfix button-group filters-button-group">
                        <li class="grid_sorting_button button d-flex flex-column justify-content-center align-items-center active is-checked" data-filter="*">all</li>
                        <li class="grid_sorting_button button d-flex flex-column justify-content-center align-items-center" data-filter=".T Shirt">women's</li>
                        <li class="grid_sorting_button button d-flex flex-column justify-content-center align-items-center" data-filter=".aksesoris">accessories</li>
                        <li class="grid_sorting_button button d-flex flex-column justify-content-center align-items-center" data-filter=".Pria">men's</li>
                    </ul>
                </div>
            </div>
        </div>




        <div class="row">
            <div class="col">
                <div class="product-grid" data-isotope='{ "itemSelector": ".product-item", "layoutMode": "fitRows" }'>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-item <?php echo e($product->product_category_id); ?> text-right">
                            <div class="product product_filter">
                                <div class="product_image">
                                    <?php if($product->productImage->isNotEmpty()): ?>
                                        <img src="<?php echo e(asset($product->productImage->first()['url'])); ?>" alt="<?php echo e($product->name); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="favorite"></div>
                                <div class="product_info">
                                    <h6 class="product_name"><a href="<?php echo e(route('site.produk.getIndex', $product->id)); ?>"><?php echo e($product->name); ?></a></h6>
                                    <div class="product_price">$<?php echo e($product->price); ?></div>
                                </div>
                            </div>
                            <div class="red_button add_to_cart_button"><a href="#">add to cart</a></div>
                        </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>



            </div>


           </div>
       </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-content'); ?>
<!-- Additional content here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<!-- Additional JavaScript here -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.min.js"></script>
<script>
    $(document).ready(function() {
        var $grid = $('.product-grid').isotope({
            itemSelector: '.product-item',
            layoutMode: 'fitRows'
        });

        $('.filters-button-group li').on('click', function() {
            var filterValue = $(this).attr('data-filter');
            $grid.isotope({
                filter: filterValue
            });

            $('.filters-button-group li').removeClass('active');
            $(this).addClass('active');
        });
    });

    setTimeout(function() {
        document.getElementById('welcomeMessage').style.display = 'none';
    }, 5000);
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-script'); ?>
<!-- Additional script here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewModifyOnlineShop-App\resources\views/site/home/index.blade.php ENDPATH**/ ?>