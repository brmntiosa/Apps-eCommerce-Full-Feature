<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Product;
use App\Models\ProductImage;


class ProductImages extends Seeder
{
    public function run(): void
    {
        // Contoh seeder, Anda dapat menyesuaikannya sesuai kebutuhan Anda
        $products = Product::all();

        foreach ($products as $product) {
            // Misalnya, setiap produk memiliki 5 gambar
            for ($i = 1; $i <= 5; $i++) {
                ProductImage::create([
                    'product_id' => $product->id,
                    'url' => 'global/landingpage/images' . $i . '.jpg', // Sesuaikan dengan path dan nama file sesuai kebutuhan Anda
                ]);
            }
        }
    }
}
