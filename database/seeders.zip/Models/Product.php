<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $table = 'products'; // Sesuaikan dengan nama tabel yang diinginkan

    protected $fillable = [
        'name',
        'product_category_id',
        'description',
        'price',
        'stock',
        'status',
    ];

    public $timestamps = false;
}
